
import React, { useState, useEffect } from 'react';
import { Transaction, TransactionType, Category, Goal } from '../types';
import { XMarkIcon } from './icons';

interface EditTransactionModalProps {
  isOpen: boolean;
  onClose: () => void;
  transaction: Transaction | null;
  onUpdateTransaction: (transaction: Transaction) => void;
  categories: Category[];
  goals: Goal[];
}

export const EditTransactionModal: React.FC<EditTransactionModalProps> = ({
  isOpen,
  onClose,
  transaction,
  onUpdateTransaction,
  categories,
  goals,
}) => {
  const [formData, setFormData] = useState<Omit<Transaction, 'id' | 'currency'> & { currency?: 'ARS' | 'USD' } | null>(null);

  useEffect(() => {
    if (transaction) {
      // Omit id from form data
      const { id, ...rest } = transaction;
      setFormData({
          ...rest,
          currency: rest.currency || 'ARS'
      });
    } else {
        setFormData(null);
    }
  }, [transaction]);

  // Fix: Correctly handle checkbox change event by improving type narrowing.
  // The `checked` property is only available on `HTMLInputElement`, and the original
  // type guard was not being correctly applied by TypeScript.
  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const target = e.target;
    const name = target.name;
    
    if (target instanceof HTMLInputElement && target.type === 'checkbox') {
        setFormData(prev => prev ? { ...prev, [name]: target.checked } : null);
    } else {
        setFormData(prev => prev ? { ...prev, [name]: target.value } : null);
    }
  };
  
  const handleTypeChange = (newType: TransactionType) => {
    setFormData(prev => prev ? { ...prev, type: newType, categoryId: '', goalId: undefined } : null);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData || !transaction) return;
    
    if (!formData.description || !formData.amount || !formData.date || !formData.categoryId) {
        alert('Por favor, complete todos los campos.');
        return;
    }
    
    const updatedTransaction: Transaction = {
      ...formData,
      id: transaction.id,
      amount: parseFloat(String(formData.amount)),
      isHabitual: formData.type === TransactionType.INCOME ? false : formData.isHabitual,
    };

    if (formData.type !== TransactionType.SAVING) {
      delete updatedTransaction.currency;
      delete updatedTransaction.goalId;
    } else {
        if (formData.currency !== 'ARS' || !formData.goalId) {
            delete updatedTransaction.goalId;
        }
    }


    onUpdateTransaction(updatedTransaction);
  };

  if (!isOpen || !formData) return null;

  const filteredCategories = categories.filter(c => c.type === formData.type);

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 z-50 flex justify-center items-center p-4">
      <div className="bg-slate-50 dark:bg-slate-800 rounded-xl shadow-2xl w-full max-w-lg transform transition-all animate-fade-in-up">
        <div className="p-6">
          <div className="flex justify-between items-center mb-6">
            <h2 className="text-2xl font-bold text-slate-800 dark:text-white">Editar Transacción</h2>
            <button onClick={onClose} className="p-2 rounded-full text-slate-500 dark:text-slate-400 hover:bg-slate-200 dark:hover:bg-slate-700">
              <XMarkIcon className="w-6 h-6" />
            </button>
          </div>

          <form onSubmit={handleSubmit} className="space-y-4">
            {/* Type Toggle */}
            <div className="grid grid-cols-3 gap-2 rounded-lg bg-slate-100 dark:bg-slate-700 p-1">
                <button type="button" onClick={() => handleTypeChange(TransactionType.EXPENSE)} className={`px-4 py-2 text-sm font-medium rounded-md transition-colors ${formData.type === TransactionType.EXPENSE ? 'bg-red-500 text-white' : 'text-slate-600 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-600'}`}>Gasto</button>
                <button type="button" onClick={() => handleTypeChange(TransactionType.INCOME)} className={`px-4 py-2 text-sm font-medium rounded-md transition-colors ${formData.type === TransactionType.INCOME ? 'bg-green-500 text-white' : 'text-slate-600 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-600'}`}>Ingreso</button>
                <button type="button" onClick={() => handleTypeChange(TransactionType.SAVING)} className={`px-4 py-2 text-sm font-medium rounded-md transition-colors ${formData.type === TransactionType.SAVING ? 'bg-blue-500 text-white' : 'text-slate-600 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-600'}`}>Ahorro</button>
            </div>

            {/* Form Fields */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label htmlFor="edit-description" className="block text-sm font-medium text-slate-600 dark:text-slate-300">Descripción</label>
                <input type="text" id="edit-description" name="description" value={formData.description} onChange={handleChange} className="mt-1 block w-full px-3 py-2 bg-white dark:bg-slate-700 border border-slate-300 dark:border-slate-600 rounded-md shadow-sm text-slate-800 dark:text-slate-200 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm" required />
              </div>
              <div>
                <label htmlFor="edit-amount" className="block text-sm font-medium text-slate-600 dark:text-slate-300">Monto</label>
                <input type="number" id="edit-amount" name="amount" value={formData.amount} onChange={handleChange} className="mt-1 block w-full px-3 py-2 bg-white dark:bg-slate-700 border border-slate-300 dark:border-slate-600 rounded-md shadow-sm text-slate-800 dark:text-slate-200 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm" required />
              </div>
              <div>
                <label htmlFor="edit-category" className="block text-sm font-medium text-slate-600 dark:text-slate-300">Categoría</label>
                <select id="edit-category" name="categoryId" value={formData.categoryId} onChange={handleChange} className="mt-1 block w-full pl-3 pr-10 py-2 text-base bg-white dark:bg-slate-700 border border-slate-300 dark:border-slate-600 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm rounded-md text-slate-800 dark:text-slate-200" required>
                  <option value="" disabled>Seleccione una categoría</option>
                  {filteredCategories.map(cat => (
                    <option key={cat.id} value={cat.id}>{cat.name}</option>
                  ))}
                </select>
              </div>
              <div>
                <label htmlFor="edit-date" className="block text-sm font-medium text-slate-600 dark:text-slate-300">Fecha</label>
                <input type="date" id="edit-date" name="date" value={formData.date} onChange={handleChange} className="mt-1 block w-full px-3 py-2 bg-white dark:bg-slate-700 border border-slate-300 dark:border-slate-600 rounded-md shadow-sm text-slate-800 dark:text-slate-200 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm" required />
              </div>
            </div>
            
            { formData.type === TransactionType.SAVING && (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label htmlFor="edit-currency" className="block text-sm font-medium text-slate-600 dark:text-slate-300">Moneda</label>
                  <select id="edit-currency" name="currency" value={formData.currency} onChange={handleChange} className="mt-1 block w-full pl-3 pr-10 py-2 text-base bg-white dark:bg-slate-700 border border-slate-300 dark:border-slate-600 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm rounded-md text-slate-800 dark:text-slate-200">
                    <option value="ARS">Pesos (ARS)</option>
                    <option value="USD">Dólares (USD)</option>
                  </select>
                </div>
                {formData.currency === 'ARS' && goals.length > 0 && (
                  <div>
                    <label htmlFor="edit-goalId" className="block text-sm font-medium text-slate-600 dark:text-slate-300">Asignar a Objetivo</label>
                    <select id="edit-goalId" name="goalId" value={formData.goalId || ''} onChange={handleChange} className="mt-1 block w-full pl-3 pr-10 py-2 text-base bg-white dark:bg-slate-700 border border-slate-300 dark:border-slate-600 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm rounded-md text-slate-800 dark:text-slate-200">
                      <option value="">No asignar</option>
                      {goals.map(goal => (
                        <option key={goal.id} value={goal.id}>{goal.name}</option>
                      ))}
                    </select>
                  </div>
                )}
              </div>
            )}

            {(formData.type === TransactionType.EXPENSE || formData.type === TransactionType.SAVING) && (
              <div className="flex items-center">
                <input id="edit-isHabitual" name="isHabitual" type="checkbox" checked={formData.isHabitual} onChange={handleChange} className="h-4 w-4 text-indigo-600 focus:ring-indigo-500 border-slate-300 rounded" />
                <label htmlFor="edit-isHabitual" className="ml-2 block text-sm text-slate-900 dark:text-slate-200">Marcar como gasto/ahorro habitual</label>
              </div>
            )}

            <div className="flex justify-end gap-4 pt-4">
                <button type="button" onClick={onClose} className="py-2 px-4 border border-slate-300 dark:border-slate-600 rounded-md shadow-sm text-sm font-medium text-slate-700 dark:text-slate-200 bg-white dark:bg-slate-700 hover:bg-slate-50 dark:hover:bg-slate-600">
                    Cancelar
                </button>
                <button type="submit" className="py-2 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-indigo-600 hover:bg-indigo-700">
                    Guardar Cambios
                </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
};
